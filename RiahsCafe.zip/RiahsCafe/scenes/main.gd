extends Node
## Main
##
## Top-level scene switcher. Listens to GameManager.state and swaps the
## active child scene accordingly. Kept intentionally minimal - all real
## logic lives in the systems being displayed, not here.

@export var main_menu_scene: PackedScene = preload("res://ui/main_menu.tscn")
@export var cafe_scene: PackedScene = preload("res://scenes/cafe.tscn")
@export var hud_scene: PackedScene = preload("res://ui/hud.tscn")

var _current_screen: Node
var _hud: Node


func _ready() -> void:
	_show_main_menu()


func _show_main_menu() -> void:
	_clear_current()
	_current_screen = main_menu_scene.instantiate()
	add_child(_current_screen)
	if _current_screen.has_signal("start_pressed"):
		_current_screen.start_pressed.connect(_on_start_pressed)


func _on_start_pressed() -> void:
	GameManager.start_new_game()
	_show_cafe()


func _show_cafe() -> void:
	_clear_current()
	_current_screen = cafe_scene.instantiate()
	add_child(_current_screen)
	_hud = hud_scene.instantiate()
	add_child(_hud)


func _clear_current() -> void:
	if _current_screen:
		_current_screen.queue_free()
		_current_screen = null
	if _hud:
		_hud.queue_free()
		_hud = null
