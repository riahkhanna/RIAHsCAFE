extends Node2D
## Cafe
##
## The playable café floor. Its only real job is telling CustomerSpawner
## where THIS level's spawn/exit/queue points are - all gameplay logic
## already lives in the autoload systems and the Table/CookingStation
## nodes placed as children in the editor. A "second location" unlock
## is just a new scene with this same script attached to different art.

@onready var _spawn_point: Marker2D = $SpawnPoint
@onready var _exit_point: Marker2D = $ExitPoint
@onready var _queue_markers: Node2D = $QueueMarkers
@onready var _customer_container: Node2D = $Customers


func _ready() -> void:
	var markers: Array[Node2D] = []
	for child in _queue_markers.get_children():
		if child is Node2D:
			markers.append(child)
	CustomerSpawner.register_level_points(_spawn_point, _exit_point, markers, _customer_container)

	_register_starter_ingredients()


func _register_starter_ingredients() -> void:
	# Bootstraps a playable inventory so a fresh save isn't immediately
	# stuck with an empty kitchen. Real content authoring (full
	# ingredient list matching every RecipeResource) belongs in a
	# dedicated data file once the menu is fully authored - see README.
	InventoryManager.register_ingredient("coffee_beans", "Coffee Beans", 2, 40)
	InventoryManager.register_ingredient("milk", "Milk", 1, 40)
	InventoryManager.register_ingredient("flour", "Flour", 1, 30)
	InventoryManager.register_ingredient("sugar", "Sugar", 1, 30)
	InventoryManager.register_ingredient("eggs", "Eggs", 2, 24)
