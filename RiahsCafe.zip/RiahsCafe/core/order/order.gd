class_name Order
extends RefCounted
## Order
##
## A single order placed by a customer. Plain RefCounted, not a Node -
## orders don't need to live in the scene tree, they're pure state that
## flows between systems (Customer -> OrderManager -> KitchenManager ->
## back to Customer/Table) via the EventBus. Keeping this out of the
## scene tree avoids node-creation overhead for what is a very
## high-churn object (dozens of orders per in-game day).

enum Status { PLACED, QUEUED, COOKING, READY, SERVED, FAILED }

var id: String
var customer: Node # weak-ish reference; orders should never outlive their customer
var table: Node
var items: Array[MenuItemResource] = []
var status: Status = Status.PLACED

var placed_at_msec: int
var cook_started_at_msec: int = -1
var ready_at_msec: int = -1

## 0-1 quality score, computed by CookingStation based on staff skill,
## station tier, and whether the order was rushed. Feeds into customer
## satisfaction and reputation. Set once ALL items are cooked (see
## report_item_cooked) - averaged across items for multi-dish orders.
var quality: float = 1.0

var _items_ready_count: int = 0
var _quality_sum: float = 0.0

static var _next_id: int = 0


static func create(customer_ref: Node, table_ref: Node, order_items: Array[MenuItemResource]) -> Order:
	var order := Order.new()
	_next_id += 1
	order.id = "order_%d" % _next_id
	order.customer = customer_ref
	order.table = table_ref
	order.items = order_items
	order.placed_at_msec = Time.get_ticks_msec()
	return order


func get_total_price() -> int:
	var total := 0
	for item in items:
		total += item.base_price
	return total


func get_total_cook_time() -> float:
	var total := 0.0
	for item in items:
		if item.recipe:
			total += item.recipe.base_cook_time_seconds
	return total


func elapsed_wait_seconds() -> float:
	return (Time.get_ticks_msec() - placed_at_msec) / 1000.0


## Called once per individual dish as its cooking station finishes it.
## Returns true only when EVERY item in the order has been cooked -
## that's the signal CookingStation should use to decide whether to
## fire order_ready, rather than firing it on the first dish to finish.
func report_item_cooked(item_quality: float) -> bool:
	_items_ready_count += 1
	_quality_sum += item_quality
	if _items_ready_count >= items.size():
		quality = _quality_sum / max(items.size(), 1)
		return true
	return false
