class_name Table
extends Node2D
## Table
##
## A physical table placed in the café scene. Pure state + geometry -
## no knowledge of customers beyond "who is currently seated here".
## TableManager owns allocation logic; this node just reports its own
## capacity and status so it stays reusable (a "VIP booth" is just a
## Table with different exported values, no subclass needed).

enum State { AVAILABLE, RESERVED, OCCUPIED, DIRTY }

@export var capacity: int = 2
@export var is_vip_only: bool = false
@export var seat_marker: Marker2D # child node marking where customers sit

var state: State = State.AVAILABLE:
	set(value):
		if state == value:
			return
		state = value
		EventBus.table_state_changed.emit(self, state)

var occupying_customer: Node = null


func _ready() -> void:
	TableManager.register_table(self)


func _exit_tree() -> void:
	TableManager.unregister_table(self)


func get_seat_position() -> Vector2:
	if seat_marker:
		return seat_marker.global_position
	return global_position


func seat_customer(customer: Node) -> void:
	occupying_customer = customer
	state = State.OCCUPIED


func vacate() -> void:
	occupying_customer = null
	state = State.DIRTY
	EventBus.table_needs_cleaning.emit(self)
	_start_auto_clean_fallback()


func _start_auto_clean_fallback() -> void:
	# PLACEHOLDER: until a dedicated cleaning-staff task/mini-game exists
	# (see README roadmap), tables clean themselves after a short delay
	# so the core loop stays playable end-to-end. Once staff cleaning
	# tasks are implemented, replace this with StaffManager assigning a
	# cleaning duty and call mark_cleaned() from there instead.
	await get_tree().create_timer(6.0).timeout
	if state == State.DIRTY:
		mark_cleaned()


func mark_cleaned() -> void:
	state = State.AVAILABLE
	EventBus.table_cleaned.emit(self)


func is_available_for(party_size: int) -> bool:
	return state == State.AVAILABLE and party_size <= capacity
