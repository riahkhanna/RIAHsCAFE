class_name RecipeResource
extends Resource
## RecipeResource
##
## Defines what a dish costs to make (in ingredients) and how long it
## takes. Separated from MenuItemResource so the same recipe could
## theoretically back multiple menu items (e.g. a "Seasonal Latte"
## re-skin), and so kitchen upgrades can affect cook_time without
## touching pricing data.

@export var id: String = ""

## ingredient_id -> quantity required per serving.
@export var ingredients: Dictionary = {}

@export var base_cook_time_seconds: float = 8.0
@export var required_station_type: String = "generic" # "stove" | "oven" | "espresso" | "generic"
@export var required_skill_level: int = 1 # staff skill needed to cook this cleanly

## Multiplier applied to final dish quality if a staff member below
## required_skill_level attempts it anyway (burnt coffee, etc).
@export_range(0.0, 1.0) var understaffed_quality_penalty: float = 0.4
