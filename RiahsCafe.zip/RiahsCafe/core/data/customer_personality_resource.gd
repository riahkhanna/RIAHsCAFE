class_name CustomerPersonalityResource
extends Resource
## CustomerPersonalityResource
##
## Data-driven personality archetype. This is the single biggest lever
## for "avoid repetitive gameplay" - by authoring 6-10 of these as .tres
## assets, every customer that walks in behaves differently without a
## single new line of state-machine code. New personality = new asset,
## not new code.

@export var id: String = ""
@export var display_name: String = ""
@export var portrait: Texture2D

@export_group("Patience")
## Base seconds customer will wait before satisfaction starts dropping.
@export var base_patience_seconds: float = 45.0
@export_range(0.1, 3.0) var patience_decay_rate: float = 1.0

@export_group("Spending")
@export_range(0.5, 3.0) var tip_multiplier: float = 1.0
@export var min_order_items: int = 1
@export var max_order_items: int = 2

@export_group("Reactions")
## How strongly quality/wait swings affect displayed mood & reputation
## contribution. A "Critic" personality would set this high.
@export_range(0.1, 3.0) var reaction_intensity: float = 1.0
@export var is_vip: bool = false
@export_range(1.0, 5.0) var vip_reputation_weight: float = 1.0

@export_group("Preferences")
@export var preferred_categories: Array[String] = []
@export var dialogue_lines: Dictionary = {} # e.g. {"waiting": [...], "served": [...], "angry": [...]}
