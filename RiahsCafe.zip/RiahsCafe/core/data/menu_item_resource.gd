class_name MenuItemResource
extends Resource
## MenuItemResource
##
## Data-only definition of something the café sells. Designers author
## these as .tres files in the editor - zero code changes needed to add
## a new dish. Keeping this pure data (no logic) is what makes the menu
## fully data-driven and moddable.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var icon: Texture2D

@export_group("Pricing")
@export var base_price: int = 10
@export var unlock_level: int = 1 # player level required to sell this

@export_group("Recipe")
@export var recipe: Resource # RecipeResource, forward-declared to avoid cyclic preload

@export_group("Customer Appeal")
## Which CustomerPersonality ids this dish is especially popular with.
## Used by CustomerAI to bias ordering choices and satisfaction bonus.
@export var favored_by: Array[String] = []
@export_range(0.0, 2.0) var base_satisfaction_multiplier: float = 1.0

@export_group("Category")
@export_enum("Beverage", "Pastry", "Light Meal", "Dessert", "Seasonal") var category: String = "Beverage"
