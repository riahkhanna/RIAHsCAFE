class_name Customer
extends CharacterBody2D
## Customer
##
## Thin host for the Customer FSM. Deliberately contains almost no
## decision logic itself - it owns shared state (position, patience,
## references) that CustomerState subclasses read/write, and delegates
## all behavior to whichever state is current. See core/customer/states/.

@export var move_speed: float = 90.0
@export var arrival_tolerance: float = 4.0

var personality: CustomerPersonalityResource
var party_size: int = 1
var display_name: String = "Guest"

var assigned_table: Node = null
var active_order: Order = null
var final_satisfaction: float = 0.0
var pending_leave_reason: String = ""
var critical_warned: bool = false

var patience: float = 1.0 # normalized 0-1, 1 = fully patient
var global_position_target: Vector2

var _current_state: CustomerState = null

@onready var _patience_bar: ProgressBar = get_node_or_null("PatienceBar")
@onready var _name_label: Label = get_node_or_null("NameLabel")


func _ready() -> void:
	global_position_target = global_position
	if _name_label:
		_name_label.text = display_name
	_change_state(StateSeekingTable.new())


func setup(personality_resource: CustomerPersonalityResource, party_size_value: int = 1) -> void:
	personality = personality_resource
	party_size = party_size_value
	display_name = personality_resource.display_name


func _physics_process(delta: float) -> void:
	_move_toward_target(delta)
	if _current_state:
		_current_state.update(delta)
		var next_state := _current_state.get_transition()
		if next_state:
			_change_state(next_state)
	if _patience_bar:
		_patience_bar.value = patience * 100.0
		_patience_bar.visible = patience < 1.0
		var bar_color := Color(0.35, 0.75, 0.45)
		if patience < 0.6:
			bar_color = Color(0.9, 0.7, 0.25)
		if patience < 0.3:
			bar_color = Color(0.85, 0.3, 0.3)
		_patience_bar.modulate = bar_color


func _move_toward_target(delta: float) -> void:
	var to_target := global_position_target - global_position
	if to_target.length() <= arrival_tolerance:
		velocity = Vector2.ZERO
		return
	velocity = to_target.normalized() * move_speed
	move_and_slide()


func has_arrived_at(target: Vector2, tolerance: float = -1.0) -> bool:
	var tol := arrival_tolerance if tolerance < 0.0 else tolerance
	return global_position.distance_to(target) <= tol


func drain_patience(delta_seconds: float) -> void:
	if personality == null:
		return
	var decay_per_second := 1.0 / max(personality.base_patience_seconds, 1.0)
	patience = clampf(patience - decay_per_second * personality.patience_decay_rate * delta_seconds, 0.0, 1.0)


func set_queue_slot(index: int) -> void:
	# Positions the customer along a visual queue line. Actual world
	# coordinates come from CustomerSpawner's authored queue markers.
	global_position_target = CustomerSpawner.get_queue_slot_position(index)


func queue_free_self() -> void:
	queue_free()


func _change_state(new_state: CustomerState) -> void:
	if _current_state:
		_current_state.exit()
	_current_state = new_state
	_current_state.enter(self)
