class_name CustomerState
extends RefCounted
## CustomerState
##
## Base class for the Customer FSM (classic State pattern). Each concrete
## state is a small, testable object that only knows how to do one thing.
## This is deliberately chosen over a giant match/switch in Customer.gd:
## adding a new behavior (e.g. a "Complaining" state for bad food) means
## adding one new file, not touching every existing branch.

var customer: Node # back-reference, set by Customer when entering state


func enter(_customer: Node) -> void:
	customer = _customer


func exit() -> void:
	pass


func update(_delta: float) -> void:
	pass


## Returns the CustomerState to transition to, or null to stay in this
## state. Kept separate from update() so transition logic reads clearly
## at the call site in Customer.gd.
func get_transition() -> CustomerState:
	return null
