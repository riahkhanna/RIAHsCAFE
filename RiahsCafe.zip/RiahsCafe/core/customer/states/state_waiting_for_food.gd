class_name StateWaitingForFood
extends CustomerState
## Customer sits patiently (or not) while their order cooks. Patience
## drains at the personality's decay rate, modified by ambience
## (decorations, music) which DecorationManager exposes as a global
## comfort scalar - a cozy café literally buys the player more time.

var _order_ready: bool = false


func enter(_customer: Node) -> void:
	super(_customer)
	EventBus.order_ready.connect(_on_order_ready)


func exit() -> void:
	if EventBus.order_ready.is_connected(_on_order_ready):
		EventBus.order_ready.disconnect(_on_order_ready)


func update(delta: float) -> void:
	if _order_ready:
		return
	var comfort_scalar: float = AmbianceService.get_comfort_scalar()
	# Higher comfort => slower decay (patience lasts longer).
	customer.drain_patience(delta / max(comfort_scalar, 0.1))

	if customer.patience <= 0.4 and not customer.critical_warned:
		customer.critical_warned = true
		EventBus.customer_patience_critical.emit(customer)

	if customer.patience <= 0.0:
		customer.pending_leave_reason = "impatient"


func get_transition() -> CustomerState:
	if customer.pending_leave_reason != "":
		OrderManager.cancel_order(customer.active_order)
		return StateLeaving.new(customer.pending_leave_reason)
	if _order_ready:
		return StateEating.new()
	return null


func _on_order_ready(order: Order) -> void:
	if order == customer.active_order:
		EventBus.customer_order_received.emit(customer, order)
		_order_ready = true
