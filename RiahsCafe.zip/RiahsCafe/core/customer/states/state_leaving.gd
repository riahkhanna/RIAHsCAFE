class_name StateLeaving
extends CustomerState
## Terminal state. Walks the customer to the exit, frees the table (and
## flags it dirty for cleaning staff), then queues the node for removal.
## `reason` is preserved for analytics/reviews (StateLeaving with reason
## "impatient" should generate a bad review; "served" a good one).

var reason: String
var _exit_point: Vector2
const WALK_TOLERANCE := 6.0


func _init(leave_reason: String) -> void:
	reason = leave_reason


func enter(_customer: Node) -> void:
	super(_customer)
	if customer.assigned_table:
		TableManager.release_table(customer.assigned_table)
		customer.assigned_table = null
	_exit_point = CustomerSpawner.get_exit_point()
	customer.global_position_target = _exit_point

	ReviewService.generate_review(customer, reason)
	EventBus.customer_left.emit(customer, reason)


func update(_delta: float) -> void:
	pass


func get_transition() -> CustomerState:
	if customer.has_arrived_at(_exit_point, WALK_TOLERANCE):
		customer.queue_free_self()
	return null
