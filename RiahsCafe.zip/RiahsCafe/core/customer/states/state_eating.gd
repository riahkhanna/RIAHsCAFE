class_name StateEating
extends CustomerState
## Customer eats/drinks their order. This is where final satisfaction is
## computed from wait time + dish quality + personality reaction
## intensity, then converted into payment (with tip) and reputation
## impact. Deliberately front-loads the "reveal" (satisfaction visible
## immediately) but keeps the customer seated for a beat so the eating
## animation/juice has room to play.

const EAT_DURATION := 4.0
var _timer: float = 0.0
var _resolved: bool = false


func enter(_customer: Node) -> void:
	super(_customer)
	_resolve_satisfaction()


func update(delta: float) -> void:
	_timer += delta


func get_transition() -> CustomerState:
	if _timer >= EAT_DURATION:
		return StateLeaving.new("served")
	return null


func _resolve_satisfaction() -> void:
	var order: Order = customer.active_order
	var personality: CustomerPersonalityResource = customer.personality

	var wait_ratio := clampf(order.elapsed_wait_seconds() / max(personality.base_patience_seconds, 1.0), 0.0, 2.0)
	var wait_score := clampf(1.0 - wait_ratio * 0.5, 0.0, 1.0)
	var quality_score := order.quality

	var raw_satisfaction := (wait_score * 0.45 + quality_score * 0.55)
	raw_satisfaction = clampf(raw_satisfaction, 0.0, 1.0)

	# Reaction intensity exaggerates both good and bad outcomes for
	# stronger-personality customers (critics love/hate more visibly).
	var centered := raw_satisfaction - 0.5
	var exaggerated := clampf(0.5 + centered * personality.reaction_intensity, 0.0, 1.0)

	customer.final_satisfaction = exaggerated
	EventBus.customer_satisfaction_changed.emit(customer, exaggerated)

	var base_total := order.get_total_price()
	var tip_scalar := lerpf(0.0, 0.35, exaggerated) * personality.tip_multiplier
	var total_paid := int(round(base_total * (1.0 + tip_scalar)))
	EconomyManager.earn(total_paid, "Order served (%s)" % customer.personality.display_name)

	var rep_weight: float = personality.vip_reputation_weight if personality.is_vip else 1.0
	GameManager.adjust_reputation(centered * 2.0 * rep_weight)

	EventBus.order_served.emit(order)
	order.status = Order.Status.SERVED
