class_name StateSeekingTable
extends CustomerState
## Customer has just spawned and is looking for a free table. If none is
## available they join the queue; queue advancement will retry this state.

var _table_claimed: Node = null
var _gave_up: bool = false


func enter(_customer: Node) -> void:
	super(_customer)
	var table := TableManager.request_table(customer.party_size)
	if table:
		_table_claimed = table
		customer.assigned_table = table
		customer.global_position_target = table.get_seat_position()
	else:
		QueueManager.join_queue(customer)
		EventBus.queue_joined.emit(customer)


func update(delta: float) -> void:
	if _table_claimed:
		return
	# While queued, patience still drains, just slower (they can see the
	# café and decide it's worth the wait).
	customer.drain_patience(delta * 0.5)
	if customer.patience <= 0.0:
		_gave_up = true


func get_transition() -> CustomerState:
	if _table_claimed and customer.has_arrived_at(customer.global_position_target):
		_table_claimed.seat_customer(customer)
		EventBus.customer_seated.emit(customer, _table_claimed)
		return StateOrdering.new()
	if _gave_up:
		QueueManager.leave_queue(customer)
		return StateLeaving.new("no_table")
	return null
