class_name StateOrdering
extends CustomerState
## Customer is seated and choosing what to order. Decision is weighted by
## personality preferences and what's actually unlocked/in stock, then
## submitted to OrderManager.

var _order_placed: bool = false
const DECISION_TIME := 2.5 # seconds spent "browsing the menu"
var _timer: float = 0.0


func enter(_customer: Node) -> void:
	super(_customer)
	_timer = 0.0


func update(delta: float) -> void:
	if _order_placed:
		return
	_timer += delta
	if _timer >= DECISION_TIME:
		var chosen := _choose_items()
		if chosen.is_empty():
			# Nothing available to order (out of stock / nothing unlocked) -
			# customer leaves disappointed rather than soft-locking.
			EventBus.customer_left.emit(customer, "no_table")
			_order_placed = true
			customer.pending_leave_reason = "menu_unavailable"
			return
		var order := Order.create(customer, customer.assigned_table, chosen)
		customer.active_order = order
		OrderManager.submit_order(order)
		EventBus.customer_order_placed.emit(customer, order)
		_order_placed = true


func get_transition() -> CustomerState:
	if customer.pending_leave_reason != "":
		return StateLeaving.new(customer.pending_leave_reason)
	if _order_placed and customer.active_order:
		return StateWaitingForFood.new()
	return null


func _choose_items() -> Array[MenuItemResource]:
	var menu: Array[MenuItemResource] = MenuService.get_available_items()
	if menu.is_empty():
		return []

	var personality: CustomerPersonalityResource = customer.personality
	var weighted: Array[MenuItemResource] = []
	for item in menu:
		var weight := 1
		if item.category in personality.preferred_categories:
			weight += 2
		if personality.id in item.favored_by:
			weight += 2
		for i in weight:
			weighted.append(item)

	var count := clampi(
		randi_range(personality.min_order_items, personality.max_order_items),
		1, weighted.size()
	)
	var chosen: Array[MenuItemResource] = []
	var pool := weighted.duplicate()
	for i in count:
		if pool.is_empty():
			break
		var pick: MenuItemResource = pool[randi() % pool.size()]
		chosen.append(pick)
		pool = pool.filter(func(m): return m != pick)
	return chosen
