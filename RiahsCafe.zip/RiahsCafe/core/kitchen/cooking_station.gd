class_name CookingStation
extends Node2D
## CookingStation
##
## A physical kitchen appliance (stove/oven/espresso machine). Processes
## exactly one order at a time - throughput is scaled by buying MORE
## stations or upgrading tier, never by letting one station multitask,
## which keeps the kitchen-management minigame meaningful (queueing
## strategy matters).

@export var station_type: String = "generic"
@export var tier: int = 1 # higher tiers cook faster / better quality
@export_range(0.5, 1.5) var speed_multiplier: float = 1.0

var is_busy: bool = false
var _current_order: Order = null
var _current_recipe: RecipeResource = null
var _elapsed: float = 0.0
var _duration: float = 0.0
var _assigned_staff_skill: int = 1


func _ready() -> void:
	KitchenManager.register_station(self)


func _exit_tree() -> void:
	KitchenManager.unregister_station(self)


func can_accept(recipe: RecipeResource) -> bool:
	return not is_busy and recipe.required_station_type == station_type


func start_cooking(order: Order, recipe: RecipeResource, staff_skill: int = 1) -> void:
	is_busy = true
	_current_order = order
	_current_recipe = recipe
	_assigned_staff_skill = staff_skill
	_elapsed = 0.0

	var tier_speed_bonus := 1.0 + (tier - 1) * 0.15
	_duration = recipe.base_cook_time_seconds / (speed_multiplier * tier_speed_bonus)

	# COOKING is a display-friendly approximation for orders with several
	# dishes cooking in parallel across stations; the authoritative
	# "done" signal is Order.report_item_cooked() below, not this enum.
	if order.status != Order.Status.READY:
		order.status = Order.Status.COOKING
	order.cook_started_at_msec = Time.get_ticks_msec()
	EventBus.order_cooking_started.emit(order, self)
	set_process(true)


func _process(delta: float) -> void:
	if not is_busy:
		set_process(false)
		return
	_elapsed += delta
	var progress := clampf(_elapsed / max(_duration, 0.01), 0.0, 1.0)
	EventBus.order_cooking_progress.emit(_current_order, progress)
	if progress >= 1.0:
		_finish_cooking()


func _finish_cooking() -> void:
	var order := _current_order
	var recipe := _current_recipe

	var item_quality := 1.0
	if recipe and _assigned_staff_skill < recipe.required_skill_level:
		item_quality = recipe.understaffed_quality_penalty
	item_quality *= randf_range(0.92, 1.0) # tiny natural variance, avoids robotic perfection
	item_quality = clampf(item_quality, 0.0, 1.0)

	is_busy = false
	_current_order = null
	_current_recipe = null
	set_process(false)
	KitchenManager.on_station_freed(self)

	var order_fully_done := order.report_item_cooked(item_quality)
	if order_fully_done:
		order.status = Order.Status.READY
		order.ready_at_msec = Time.get_ticks_msec()
		EventBus.order_ready.emit(order)
