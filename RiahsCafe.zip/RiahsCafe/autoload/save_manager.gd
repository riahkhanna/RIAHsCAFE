extends Node
## SaveManager
##
## Handles serialization to/from disk. Uses a plain JSON save format
## (not Godot's binary resource format) deliberately: it's human-readable
## for debugging, diffable in version control during dev, and immune to
## breaking when script class layouts change between builds.
##
## Every system that needs to persist state implements ISaveable-style
## duck typing: expose get_save_data() -> Dictionary and
## load_save_data(data: Dictionary) -> void. SaveManager doesn't know or
## care what's inside those dictionaries - it just routes them.

const SAVE_DIR := "user://saves/"
const SAVE_FILE := "savegame.json"
const SAVE_VERSION := 1

## Registered saveable systems, populated at runtime (e.g. TableManager,
## InventoryManager call register_saveable(self) in their _ready()).
## Keeping this a registry rather than a hardcoded list means new systems
## opt into persistence without editing SaveManager.
var _saveables: Dictionary = {} # id: String -> Node


func register_saveable(id: String, node: Node) -> void:
	if not (node.has_method("get_save_data") and node.has_method("load_save_data")):
		push_error("SaveManager: '%s' does not implement the saveable interface." % id)
		return
	_saveables[id] = node


func unregister_saveable(id: String) -> void:
	_saveables.erase(id)


func save_game(slot: String = "default") -> bool:
	var payload := {
		"version": SAVE_VERSION,
		"saved_at": Time.get_datetime_string_from_system(),
		"game_manager": {
			"current_day": GameManager.current_day,
			"player_level": GameManager.player_level,
			"player_xp": GameManager.player_xp,
			"xp_to_next_level": GameManager.xp_to_next_level,
			"reputation": GameManager.reputation,
			"star_rating": GameManager.star_rating,
			"unlocks": GameManager.unlocks,
		},
		"economy": {
			"money": EconomyManager.money,
		},
		"systems": {},
	}

	for id in _saveables:
		payload["systems"][id] = _saveables[id].get_save_data()

	var dir := DirAccess.open("user://")
	if dir and not dir.dir_exists(SAVE_DIR.trim_prefix("user://")):
		dir.make_dir_recursive(SAVE_DIR.trim_prefix("user://"))

	var path := SAVE_DIR + slot + "_" + SAVE_FILE
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("SaveManager: failed to open save file for writing: %s" % path)
		return false

	file.store_string(JSON.stringify(payload, "\t"))
	file.close()
	return true


func load_game(slot: String = "default") -> bool:
	var path := SAVE_DIR + slot + "_" + SAVE_FILE
	if not FileAccess.file_exists(path):
		return false

	var file := FileAccess.open(path, FileAccess.READ)
	var text := file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("SaveManager: corrupt save file at %s" % path)
		return false

	var payload: Dictionary = parsed
	if payload.get("version", 0) != SAVE_VERSION:
		push_warning("SaveManager: save version mismatch, attempting best-effort load.")

	var gm: Dictionary = payload.get("game_manager", {})
	GameManager.current_day = gm.get("current_day", 1)
	GameManager.player_level = gm.get("player_level", 1)
	GameManager.player_xp = gm.get("player_xp", 0)
	GameManager.xp_to_next_level = gm.get("xp_to_next_level", 100)
	GameManager.reputation = gm.get("reputation", 50.0)
	GameManager.star_rating = gm.get("star_rating", 3.0)
	GameManager.unlocks = gm.get("unlocks", {})

	var econ: Dictionary = payload.get("economy", {})
	EconomyManager.money = econ.get("money", 500)

	var systems: Dictionary = payload.get("systems", {})
	for id in systems:
		if _saveables.has(id):
			_saveables[id].load_save_data(systems[id])
		else:
			push_warning("SaveManager: no registered system for saved id '%s' (skipped)." % id)

	return true


func has_save(slot: String = "default") -> bool:
	return FileAccess.file_exists(SAVE_DIR + slot + "_" + SAVE_FILE)


func delete_save(slot: String = "default") -> void:
	var path := SAVE_DIR + slot + "_" + SAVE_FILE
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
