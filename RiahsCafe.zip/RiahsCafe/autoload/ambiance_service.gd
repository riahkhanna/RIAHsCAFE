extends Node
## AmbianceService
##
## Aggregates every "cozy" contributor (decorations, lighting, music
## choice, weather) into one comfort scalar consumed by CustomerAI to
## slow patience decay. This is the extension point for "Decorations
## affecting customer happiness": each placed decoration registers its
## contribution here rather than reaching into customers directly, so
## decoration count/placement can scale freely without touching AI code.

var _contributions: Dictionary = {} # source_id -> float bonus (additive)
const BASE_COMFORT := 1.0


func register_contribution(source_id: String, amount: float) -> void:
	_contributions[source_id] = amount


func remove_contribution(source_id: String) -> void:
	_contributions.erase(source_id)


## Returns a multiplier >= 1.0 typically; 1.0 = no bonus, higher = a
## cozier café that buys customers more patience.
func get_comfort_scalar() -> float:
	var total := BASE_COMFORT
	for id in _contributions:
		total += _contributions[id]
	return clampf(total, 0.5, 2.5)
