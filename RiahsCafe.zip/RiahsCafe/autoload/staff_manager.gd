extends Node
## StaffManager
##
## MINIMAL VIABLE VERSION. Full hiring/scheduling/wages UI is roadmap
## (see README), but this exists now so KitchenManager has a real skill
## value to query instead of a hardcoded magic number - the seam is
## already correct, only the UI/hiring flow around it is left to build.

class StaffMember:
	var id: String
	var display_name: String
	var skill_by_station: Dictionary = {} # station_type -> int skill level
	var wage_per_day: int = 20

var _roster: Array[StaffMember] = []


func _ready() -> void:
	SaveManager.register_saveable("staff", self)
	EventBus.day_started.connect(_on_day_started)
	# The player always starts as their own barista - solo-run is a
	# valid, intended early-game state, not a bug.
	var owner_staff := StaffMember.new()
	owner_staff.id = "owner"
	owner_staff.display_name = "You"
	owner_staff.skill_by_station = {"generic": 2, "espresso": 2, "stove": 1, "oven": 1}
	owner_staff.wage_per_day = 0
	_roster.append(owner_staff)


func hire(display_name: String, wage_per_day: int, starting_skill: int = 1) -> StaffMember:
	var member := StaffMember.new()
	member.id = "staff_%d" % _roster.size()
	member.display_name = display_name
	member.wage_per_day = wage_per_day
	member.skill_by_station = {"generic": starting_skill, "espresso": starting_skill, "stove": starting_skill, "oven": starting_skill}
	_roster.append(member)
	EventBus.staff_hired.emit(member)
	return member


func fire(member: StaffMember) -> void:
	_roster.erase(member)
	EventBus.staff_fired.emit(member)


func get_best_available_skill(station_type: String) -> int:
	var best := 1
	for member in _roster:
		best = max(best, member.skill_by_station.get(station_type, 1))
	return best


func _on_day_started(_day: int) -> void:
	var total_wages := 0
	for member in _roster:
		total_wages += member.wage_per_day
	if total_wages > 0:
		EconomyManager.charge_expense(total_wages, "Staff wages")


func get_save_data() -> Dictionary:
	var data: Array = []
	for m in _roster:
		data.append({"id": m.id, "display_name": m.display_name, "skill_by_station": m.skill_by_station, "wage_per_day": m.wage_per_day})
	return {"roster": data}


func load_save_data(data: Dictionary) -> void:
	var roster_data: Array = data.get("roster", [])
	_roster.clear()
	for d in roster_data:
		var m := StaffMember.new()
		m.id = d["id"]
		m.display_name = d["display_name"]
		m.skill_by_station = d["skill_by_station"]
		m.wage_per_day = d["wage_per_day"]
		_roster.append(m)
