extends Node
## TimeManager
##
## Drives the in-game clock, day/night cycle and time-of-day periods used
## by lighting, customer spawn tables, and rush-hour logic. Runs on a
## simple scaled-time model: N real seconds = 1 in-game day.

enum Period { MORNING, AFTERNOON, EVENING, NIGHT }

@export var seconds_per_day: float = 480.0 # 8 real minutes = 1 café day
@export var opening_hour: float = 8.0
@export var closing_hour: float = 22.0

var current_hour: float = 8.0 # 0-24, fractional
var is_running: bool = false

var _current_period: Period = Period.MORNING


func _ready() -> void:
	set_process(false)
	EventBus.day_started.connect(_on_day_started)


func _process(delta: float) -> void:
	if not is_running:
		return
	var hours_per_second := 24.0 / seconds_per_day
	current_hour += hours_per_second * delta
	if current_hour >= 24.0:
		current_hour = 0.0

	var period := _compute_period(current_hour)
	if period != _current_period:
		_current_period = period
		EventBus.time_period_changed.emit(period)

	if current_hour >= closing_hour and is_running:
		is_running = false
		set_process(false)
		GameManager.end_day()


func start_day_cycle() -> void:
	current_hour = opening_hour
	_current_period = _compute_period(current_hour)
	is_running = true
	set_process(true)


func stop_day_cycle() -> void:
	is_running = false
	set_process(false)


func get_period() -> Period:
	return _current_period


## 0.0 = closing time (lowest traffic), 1.0 = peak rush hour. Used by
## CustomerSpawner to modulate arrival frequency across the day.
func get_rush_intensity() -> float:
	# Two humps: lunch (~12-14h) and dinner (~18-20h).
	var lunch := exp(-pow(current_hour - 13.0, 2) / 2.0)
	var dinner := exp(-pow(current_hour - 19.0, 2) / 2.5)
	return clampf(max(lunch, dinner), 0.15, 1.0)


func _compute_period(hour: float) -> Period:
	if hour >= 6.0 and hour < 11.0:
		return Period.MORNING
	elif hour >= 11.0 and hour < 17.0:
		return Period.AFTERNOON
	elif hour >= 17.0 and hour < 21.0:
		return Period.EVENING
	return Period.NIGHT


func _on_day_started(_day: int) -> void:
	start_day_cycle()
