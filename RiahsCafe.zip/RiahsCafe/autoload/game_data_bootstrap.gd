extends Node
## GameDataBootstrap
##
## Loads every authored data asset (menu items, personalities) from
## res://data/ and hands them to the services that consume them. This
## exists so content designers can add a new .tres file to a folder and
## have it appear in-game with ZERO code or scene-editing required -
## the alternative (manually dragging assets into exported Inspector
## arrays on an autoload) doesn't scale past a handful of items.

const MENU_ITEMS_DIR := "res://data/menu_items/"
const PERSONALITIES_DIR := "res://data/personalities/"


func _ready() -> void:
	MenuService.full_catalog = _load_all_of_type(MENU_ITEMS_DIR, MenuItemResource)
	CustomerSpawner.personality_pool = _load_all_of_type(PERSONALITIES_DIR, CustomerPersonalityResource)


func _load_all_of_type(dir_path: String, expected_script: Script) -> Array:
	var results: Array = []
	var dir := DirAccess.open(dir_path)
	if dir == null:
		push_warning("GameDataBootstrap: could not open %s" % dir_path)
		return results

	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.ends_with(".tres"):
			var resource := load(dir_path + file_name)
			if resource != null:
				results.append(resource)
		file_name = dir.get_next()
	dir.list_dir_end()
	return results
