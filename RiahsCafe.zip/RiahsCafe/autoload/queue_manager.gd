extends Node
## QueueManager
##
## Simple FIFO line for customers waiting on a table. Deliberately dumb -
## no priority logic here. VIP skip-the-line behavior belongs in
## CustomerAI (a VIP customer could choose not to queue at all and leave
## instead), keeping this class single-purpose per SRP.

const MAX_QUEUE_SIZE := 8

var _queue: Array[Node] = []


func _ready() -> void:
	# Any time a table becomes available (fresh cleaning, or one just
	# freed up), give the front of the queue a chance to claim it.
	EventBus.table_cleaned.connect(func(_table): try_advance())


func join_queue(customer: Node) -> bool:
	if _queue.size() >= MAX_QUEUE_SIZE:
		EventBus.queue_full.emit()
		return false
	_queue.append(customer)
	_position_in_line(customer, _queue.size() - 1)
	return true


func leave_queue(customer: Node) -> void:
	_queue.erase(customer)
	_reflow()


## Called by TableManager/EventBus listener whenever a table frees up,
## so the front of the line gets first crack at it.
func try_advance() -> void:
	if _queue.is_empty():
		return
	var next_customer: Node = _queue[0]
	var table := TableManager.request_table(next_customer.party_size)
	if table:
		_queue.pop_front()
		next_customer.assigned_table = table
		next_customer.global_position_target = table.get_seat_position()
		_reflow()
		EventBus.queue_advanced.emit()


func get_queue_length() -> int:
	return _queue.size()


func get_wait_position(customer: Node) -> int:
	return _queue.find(customer)


func _reflow() -> void:
	for i in _queue.size():
		_position_in_line(_queue[i], i)


func _position_in_line(customer: Node, index: int) -> void:
	if customer.has_method("set_queue_slot"):
		customer.set_queue_slot(index)
