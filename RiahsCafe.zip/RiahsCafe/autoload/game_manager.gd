extends Node
## GameManager
##
## Owns the top-level game state machine and player progression (level,
## XP, reputation, unlocks). Does NOT own gameplay logic for customers,
## tables, etc. - those are self-contained systems that react to EventBus.
## GameManager's job is orchestration: what phase are we in, and are we
## allowed to level up / unlock things right now.

enum GameState { BOOT, MAIN_MENU, PLAYING, PAUSED, DAY_SUMMARY, GAME_OVER }

var state: GameState = GameState.BOOT:
	set(value):
		if state == value:
			return
		var previous := state
		state = value
		_on_state_changed(previous, value)

var current_day: int = 1
var player_level: int = 1
var player_xp: int = 0
var xp_to_next_level: int = 100

var reputation: float = 50.0 # 0-100, drives customer spawn rate & star rating
var star_rating: float = 3.0 # 0-5, displayed to player

## Unlock ids the player has earned. Kept as a Set-like Dictionary for O(1)
## lookup. Populated by LevelSystem definitions (data-driven, see
## core/data/level_definitions.gd once authored).
var unlocks: Dictionary = {}

var _difficulty_curve_cache: Dictionary = {}


func _ready() -> void:
	EventBus.day_ended.connect(_on_day_ended)
	EventBus.customer_left.connect(_on_customer_left)
	state = GameState.MAIN_MENU


func start_new_game() -> void:
	current_day = 1
	player_level = 1
	player_xp = 0
	xp_to_next_level = 100
	reputation = 50.0
	star_rating = 3.0
	unlocks.clear()
	state = GameState.PLAYING
	EventBus.day_started.emit(current_day)


func pause_game() -> void:
	if state != GameState.PLAYING:
		return
	state = GameState.PAUSED
	get_tree().paused = true
	EventBus.game_paused.emit(true)


func resume_game() -> void:
	if state != GameState.PAUSED:
		return
	state = GameState.PLAYING
	get_tree().paused = false
	EventBus.game_paused.emit(false)


func add_xp(amount: int) -> void:
	player_xp += amount
	while player_xp >= xp_to_next_level:
		player_xp -= xp_to_next_level
		_level_up()


func _level_up() -> void:
	player_level += 1
	# Gentle exponential curve keeps early levels fast (dopamine hooks)
	# and later levels meaningful (avoids trivializing progression).
	xp_to_next_level = int(round(xp_to_next_level * 1.35))
	EventBus.level_up.emit(player_level)


func grant_unlock(unlock_id: String) -> void:
	if unlocks.has(unlock_id):
		return
	unlocks[unlock_id] = true
	EventBus.unlock_granted.emit(unlock_id)


func is_unlocked(unlock_id: String) -> bool:
	return unlocks.get(unlock_id, false)


func adjust_reputation(delta: float) -> void:
	reputation = clampf(reputation + delta, 0.0, 100.0)
	star_rating = clampf(1.0 + (reputation / 100.0) * 4.0, 0.0, 5.0)
	EventBus.reputation_changed.emit(reputation, delta)
	EventBus.star_rating_changed.emit(star_rating)


## Called by CustomerSpawner / DifficultyDirector to scale challenge with
## day number without hardcoding numbers all over the codebase.
func get_difficulty_scalar() -> float:
	if _difficulty_curve_cache.has(current_day):
		return _difficulty_curve_cache[current_day]
	# Diminishing-returns curve: fast ramp early, plateaus later so the
	# late game stays playable rather than becoming unfair.
	var scalar := 1.0 + (1.0 - exp(-current_day / 12.0)) * 1.8
	_difficulty_curve_cache[current_day] = scalar
	return scalar


func end_day() -> void:
	if state != GameState.PLAYING:
		return
	state = GameState.DAY_SUMMARY
	var summary := {
		"day": current_day,
		"revenue": EconomyManager.get_daily_revenue(),
		"expenses": EconomyManager.get_daily_expenses(),
		"net": EconomyManager.get_daily_revenue() - EconomyManager.get_daily_expenses(),
		"reputation": reputation,
		"star_rating": star_rating,
	}
	EventBus.day_ended.emit(summary)


func advance_to_next_day() -> void:
	current_day += 1
	EconomyManager.reset_daily_counters()
	state = GameState.PLAYING
	EventBus.day_started.emit(current_day)


func _on_day_ended(_summary: Dictionary) -> void:
	# Hook point for MissionManager / AchievementManager to evaluate
	# end-of-day conditions once those systems are authored.
	pass


func _on_customer_left(_customer: Node, reason: String) -> void:
	match reason:
		"served":
			adjust_reputation(randf_range(0.1, 0.6))
			add_xp(5)
		"impatient":
			adjust_reputation(-randf_range(0.5, 1.5))
		"no_table":
			adjust_reputation(-randf_range(0.2, 0.8))


func _on_state_changed(_previous: GameState, _current: GameState) -> void:
	pass
