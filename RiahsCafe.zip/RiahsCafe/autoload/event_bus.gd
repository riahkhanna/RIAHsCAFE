extends Node
## EventBus
##
## Global signal hub. This is the ONLY way decoupled systems talk to each
## other. Nothing in core/ should hold a direct reference to a sibling
## system (e.g. Kitchen should never reach into TableManager directly).
## Instead: emit here, subscribe here. This keeps every system independently
## testable and swappable, and means adding a new system (e.g. Marketing)
## never requires editing existing systems' code.
##
## Convention: signals are named <domain>_<event>, past tense for things
## that already happened, imperative for requests.

# --- Customer lifecycle -----------------------------------------------
signal customer_spawned(customer: Node)
signal customer_seated(customer: Node, table: Node)
signal customer_order_placed(customer: Node, order: Resource)
signal customer_order_received(customer: Node, order: Resource)
signal customer_satisfaction_changed(customer: Node, satisfaction: float)
signal customer_left(customer: Node, reason: String) # "served" | "impatient" | "no_table"
signal customer_patience_critical(customer: Node)

# --- Table system --------------------------------------------------------
signal table_state_changed(table: Node, state: int)
signal table_needs_cleaning(table: Node)
signal table_cleaned(table: Node)

# --- Queue -----------------------------------------------------------
signal queue_joined(customer: Node)
signal queue_advanced()
signal queue_full()

# --- Orders / kitchen --------------------------------------------------
signal order_created(order: Resource)
signal order_sent_to_kitchen(order: Resource)
signal order_cooking_started(order: Resource, station: Node)
signal order_cooking_progress(order: Resource, progress: float)
signal order_ready(order: Resource)
signal order_served(order: Resource)
signal order_failed(order: Resource, reason: String)

# --- Inventory / economy ------------------------------------------------
signal ingredient_stock_changed(ingredient_id: String, new_amount: int)
signal ingredient_out_of_stock(ingredient_id: String)
signal money_changed(new_amount: int, delta: int)
signal expense_charged(label: String, amount: int)
signal transaction_recorded(entry: Dictionary)

# --- Progression ---------------------------------------------------------
signal reputation_changed(new_value: float, delta: float)
signal star_rating_changed(new_rating: float)
signal level_up(new_level: int)
signal day_ended(day_summary: Dictionary)
signal day_started(day_number: int)
signal unlock_granted(unlock_id: String)

# --- Staff ---------------------------------------------------------------
signal staff_hired(staff: Node)
signal staff_fired(staff: Node)
signal staff_task_assigned(staff: Node, task: Dictionary)

# --- World / meta ----------------------------------------------------
signal weather_changed(weather_type: int)
signal time_period_changed(period: int) # morning/afternoon/evening/night
signal random_event_triggered(event_id: String, payload: Dictionary)
signal game_paused(is_paused: bool)
signal settings_changed(key: String, value: Variant)
