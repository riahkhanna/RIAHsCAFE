extends Node
## KitchenManager
##
## The scheduler between OrderManager and physical CookingStation nodes.
## Holds a per-station-type backlog and greedily assigns the oldest
## waiting order to the first free matching station each time a station
## frees up or a new order arrives. This is intentionally a simple
## greedy scheduler (not an optimal bin-packing solve) - for a cozy café
## sim, a slightly imperfect kitchen queue is more charming than
## optimal, and it's O(n) instead of combinatorial.

var _stations: Array[CookingStation] = []
## station_type -> Array[Order] backlog, one order per menu item within
## a customer order gets its own kitchen ticket.
var _backlog: Dictionary = {}


func _ready() -> void:
	EventBus.order_sent_to_kitchen.connect(_on_order_sent_to_kitchen)


func register_station(station: CookingStation) -> void:
	_stations.append(station)


func unregister_station(station: CookingStation) -> void:
	_stations.erase(station)


func _on_order_sent_to_kitchen(order: Order) -> void:
	order.status = Order.Status.QUEUED
	for item in order.items:
		if item.recipe == null:
			continue
		var station_type: String = item.recipe.required_station_type
		if not _backlog.has(station_type):
			_backlog[station_type] = []
		_backlog[station_type].append({"order": order, "recipe": item.recipe})
	_dispatch()


func on_station_freed(_station: CookingStation) -> void:
	_dispatch()


func _dispatch() -> void:
	for station in _stations:
		if station.is_busy:
			continue
		var backlog_list: Array = _backlog.get(station.station_type, [])
		if backlog_list.is_empty():
			continue
		var ticket: Dictionary = backlog_list.pop_front()
		var recipe: RecipeResource = ticket["recipe"]
		var order: Order = ticket["order"]

		if not InventoryManager.has_enough(recipe.ingredients):
			# Deliberately does NOT retry or auto-refund: the ticket is
			# dropped, so this dish never completes. The customer's
			# patience timer (StateWaitingForFood) is the real recovery
			# path - they'll eventually give up and leave "impatient",
			# which is honest, readable feedback to the player that
			# stock ran out, rather than a silent soft-lock.
			EventBus.order_failed.emit(order, "out_of_stock")
			continue

		InventoryManager.consume(recipe.ingredients)
		var skill := StaffManager.get_best_available_skill(station.station_type)
		station.start_cooking(order, recipe, skill)
