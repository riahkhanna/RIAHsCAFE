extends Node
## EconomyManager
##
## Single source of truth for money. Every gain/spend in the game must
## route through here so the ledger stays consistent and auditable -
## this is what powers the "Financial Reports" / "Business Analytics"
## feature without any extra bookkeeping in gameplay code.

var money: int = 500 # starting capital

var _daily_revenue: int = 0
var _daily_expenses: int = 0
var _transaction_log: Array[Dictionary] = [] # rolling history for reports
const MAX_LOG_ENTRIES := 500


func earn(amount: int, label: String = "Sale") -> void:
	if amount <= 0:
		return
	money += amount
	_daily_revenue += amount
	_record(label, amount)
	EventBus.money_changed.emit(money, amount)


## Returns false if the player can't afford it - callers MUST check this
## before deducting stock/placing orders, never assume success.
func spend(amount: int, label: String = "Purchase") -> bool:
	if amount <= 0:
		return true
	if money < amount:
		return false
	money -= amount
	_record(label, -amount)
	EventBus.money_changed.emit(money, -amount)
	return true


## Recurring costs (rent, electricity, staff wages) that aren't tied to a
## single purchase decision. These bypass the affordability check because
## going into debt from bills is a valid (if painful) game state, whereas
## a blocked purchase should just fail.
func charge_expense(amount: int, label: String = "Expense") -> void:
	money -= amount
	_daily_expenses += amount
	_record(label, -amount)
	EventBus.expense_charged.emit(label, amount)
	EventBus.money_changed.emit(money, -amount)


func can_afford(amount: int) -> bool:
	return money >= amount


func get_daily_revenue() -> int:
	return _daily_revenue


func get_daily_expenses() -> int:
	return _daily_expenses


func reset_daily_counters() -> void:
	_daily_revenue = 0
	_daily_expenses = 0


func get_transaction_history(count: int = 50) -> Array[Dictionary]:
	var start := max(0, _transaction_log.size() - count)
	return _transaction_log.slice(start)


func _record(label: String, delta: int) -> void:
	var entry := {
		"label": label,
		"delta": delta,
		"balance_after": money,
		"day": GameManager.current_day,
		"timestamp": Time.get_ticks_msec(),
	}
	_transaction_log.append(entry)
	if _transaction_log.size() > MAX_LOG_ENTRIES:
		_transaction_log.pop_front()
	EventBus.transaction_recorded.emit(entry)
