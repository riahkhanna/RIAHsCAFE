extends Node
## OrderManager
##
## Thin orchestration layer: receives a freshly-placed Order, forwards
## it to the kitchen, and tracks in-flight orders for cancellation /
## analytics. Does not know HOW food gets cooked (that's KitchenManager's
## job) - this separation means swapping the kitchen scheduling algorithm
## later never touches order-lifecycle code.

var _active_orders: Dictionary = {} # order.id -> Order


func submit_order(order: Order) -> void:
	_active_orders[order.id] = order
	EventBus.order_created.emit(order)
	EventBus.order_sent_to_kitchen.emit(order)


func cancel_order(order: Order) -> void:
	if order == null or not _active_orders.has(order.id):
		return
	order.status = Order.Status.FAILED
	_active_orders.erase(order.id)
	EventBus.order_failed.emit(order, "cancelled")


func complete_order(order: Order) -> void:
	_active_orders.erase(order.id)


func get_active_order_count() -> int:
	return _active_orders.size()
