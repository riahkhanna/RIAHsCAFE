extends Node
## ReviewService
##
## Converts a departing customer's experience into a stored review. This
## is a deliberately small, focused seam: MissionManager/Analytics UI
## can read get_recent_reviews() without needing to know anything about
## the customer FSM that produced them.

var _reviews: Array[Dictionary] = []
const MAX_STORED_REVIEWS := 200

const LEAVE_REASON_TEXT := {
	"served": ["Lovely spot, will be back!", "Great coffee, cozy vibes.", "Exactly what I needed today."],
	"impatient": ["Waited forever, left hungry.", "Way too slow for a quick coffee break.", "Never got served."],
	"no_table": ["No seats available, had to leave.", "Too crowded, couldn't get a table."],
	"menu_unavailable": ["Nothing I wanted was available.", "Kitchen was out of everything I liked."],
}


func generate_review(customer: Node, reason: String) -> void:
	var rating := _reason_to_rating(reason, customer)
	var pool: Array = LEAVE_REASON_TEXT.get(reason, ["No comment."])
	var review := {
		"customer_name": customer.display_name if "display_name" in customer else "Guest",
		"reason": reason,
		"rating": rating,
		"comment": pool[randi() % pool.size()],
		"day": GameManager.current_day,
	}
	_reviews.append(review)
	if _reviews.size() > MAX_STORED_REVIEWS:
		_reviews.pop_front()


func get_recent_reviews(count: int = 10) -> Array[Dictionary]:
	var start := max(0, _reviews.size() - count)
	var slice: Array = _reviews.slice(start)
	var typed: Array[Dictionary] = []
	for r in slice:
		typed.append(r)
	return typed


func _reason_to_rating(reason: String, customer: Node) -> int:
	match reason:
		"served":
			var satisfaction: float = customer.final_satisfaction if "final_satisfaction" in customer else 0.7
			return clampi(int(round(satisfaction * 5.0)), 1, 5)
		"impatient":
			return 1
		"no_table", "menu_unavailable":
			return 2
		_:
			return 3
