extends Node
## InventoryManager
##
## Tracks raw ingredient stock levels. Kitchen consumes from here when
## cooking; player restocks via purchase (deducting from EconomyManager).
## Kept ignorant of recipes/orders on purpose - it only knows quantities,
## which makes it trivially unit-testable and reusable for a future
## "delivery truck" or "supplier haggling" feature.

## ingredient_id -> current stock count
var _stock: Dictionary = {}
## ingredient_id -> {display_name, unit_cost, restock_amount}
var _catalog: Dictionary = {}

const LOW_STOCK_THRESHOLD := 5


func _ready() -> void:
	SaveManager.register_saveable("inventory", self)


func register_ingredient(id: String, display_name: String, unit_cost: int, starting_stock: int = 20) -> void:
	_catalog[id] = {"display_name": display_name, "unit_cost": unit_cost}
	if not _stock.has(id):
		_stock[id] = starting_stock


func get_stock(id: String) -> int:
	return _stock.get(id, 0)


func has_enough(requirements: Dictionary) -> bool:
	for id in requirements:
		if get_stock(id) < requirements[id]:
			return false
	return true


## Atomic consume: either fully succeeds or changes nothing. Callers
## (KitchenManager) must check has_enough() first for UX purposes, but
## this guards against race-condition double-spends regardless.
func consume(requirements: Dictionary) -> bool:
	if not has_enough(requirements):
		return false
	for id in requirements:
		_stock[id] -= requirements[id]
		_notify_stock(id)
	return true


func restock(id: String, amount: int) -> bool:
	if not _catalog.has(id):
		push_error("InventoryManager: unknown ingredient '%s'" % id)
		return false
	var cost: int = _catalog[id]["unit_cost"] * amount
	if not EconomyManager.spend(cost, "Restock: %s" % _catalog[id]["display_name"]):
		return false
	_stock[id] = get_stock(id) + amount
	_notify_stock(id)
	return true


func get_low_stock_ingredients() -> Array[String]:
	var low: Array[String] = []
	for id in _stock:
		if _stock[id] <= LOW_STOCK_THRESHOLD:
			low.append(id)
	return low


func _notify_stock(id: String) -> void:
	var amount: int = _stock[id]
	EventBus.ingredient_stock_changed.emit(id, amount)
	if amount <= 0:
		EventBus.ingredient_out_of_stock.emit(id)


func get_save_data() -> Dictionary:
	return {"stock": _stock}


func load_save_data(data: Dictionary) -> void:
	_stock = data.get("stock", _stock)
