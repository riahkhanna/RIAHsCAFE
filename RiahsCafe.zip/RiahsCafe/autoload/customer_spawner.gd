extends Node
## CustomerSpawner
##
## Autoload so Customer FSM states (StateSeekingTable, StateLeaving) can
## reference exit/queue points without holding a scene-specific
## reference. The active café level registers its spawn/exit/queue
## markers here on load via register_level_points(); this keeps
## CustomerSpawner scene-agnostic (works for a future "second location"
## unlock with zero code changes).

@export var customer_scene: PackedScene = preload("res://core/customer/customer.tscn")
## Personalities available to roll from. Populate in editor or load
## from a data directory at boot.
@export var personality_pool: Array[CustomerPersonalityResource] = []

var _spawn_point: Node2D
var _exit_point: Node2D
var _queue_markers: Array[Node2D] = []
var _customer_container: Node

var _spawn_timer: float = 0.0
const BASE_SPAWN_INTERVAL := 12.0 # seconds between customers at rush=1.0, reputation=50

var _is_active: bool = false


func _process(delta: float) -> void:
	if not _is_active or _spawn_point == null:
		return
	_spawn_timer -= delta
	if _spawn_timer <= 0.0:
		_spawn_customer()
		_spawn_timer = _next_spawn_interval()


func register_level_points(spawn_point: Node2D, exit_point: Node2D, queue_markers: Array[Node2D], container: Node) -> void:
	_spawn_point = spawn_point
	_exit_point = exit_point
	_queue_markers = queue_markers
	_customer_container = container
	_is_active = true
	_spawn_timer = _next_spawn_interval()


func get_exit_point() -> Vector2:
	return _exit_point.global_position if _exit_point else Vector2.ZERO


func get_queue_slot_position(index: int) -> Vector2:
	if _queue_markers.is_empty():
		return get_exit_point()
	var clamped := clampi(index, 0, _queue_markers.size() - 1)
	return _queue_markers[clamped].global_position


func _next_spawn_interval() -> float:
	var rush := TimeManager.get_rush_intensity() if TimeManager else 0.5
	var reputation_scalar := lerpf(1.4, 0.7, GameManager.reputation / 100.0)
	var difficulty := GameManager.get_difficulty_scalar()
	var interval := (BASE_SPAWN_INTERVAL / max(rush, 0.1)) * reputation_scalar / difficulty
	return max(interval, 2.5)


func _spawn_customer() -> void:
	if personality_pool.is_empty() or customer_scene == null:
		return
	var personality: CustomerPersonalityResource = personality_pool[randi() % personality_pool.size()]

	var customer := customer_scene.instantiate() as Customer
	customer.global_position = _spawn_point.global_position
	customer.setup(personality, randi_range(1, 2))
	_customer_container.add_child(customer)
	EventBus.customer_spawned.emit(customer)
