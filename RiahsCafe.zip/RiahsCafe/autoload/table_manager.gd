extends Node
## TableManager
##
## Registry + allocator for every Table node currently placed in the
## café. Tables register themselves on _ready() (see Table's parent
## scene calling TableManager.register_table), so adding/removing
## furniture in the editor "just works" with zero manual wiring.

var _tables: Array[Table] = []


func _ready() -> void:
	SaveManager.register_saveable("table_manager", self)


func register_table(table: Table) -> void:
	if table in _tables:
		return
	_tables.append(table)
	table.state = Table.State.AVAILABLE


func unregister_table(table: Table) -> void:
	_tables.erase(table)


## Finds and reserves the best-fit table for a party (smallest table that
## still fits them, to avoid wasting large tables on solo customers).
func request_table(party_size: int) -> Table:
	var candidates := _tables.filter(func(t: Table) -> bool:
		return t.is_available_for(party_size)
	)
	if candidates.is_empty():
		return null
	candidates.sort_custom(func(a: Table, b: Table) -> bool:
		return a.capacity < b.capacity
	)
	var chosen: Table = candidates[0]
	chosen.state = Table.State.RESERVED
	return chosen


func release_table(table: Table) -> void:
	table.vacate()


func get_available_count() -> int:
	return _tables.filter(func(t: Table) -> bool:
		return t.state == Table.State.AVAILABLE
	).size()


func get_total_capacity() -> int:
	var total := 0
	for t in _tables:
		total += t.capacity
	return total


func get_save_data() -> Dictionary:
	# Table layout itself lives in the scene file; we only persist
	# purchased-furniture unlock state elsewhere. Nothing dynamic to
	# save here yet beyond a hook for future "table upgrade" tracking.
	return {}


func load_save_data(_data: Dictionary) -> void:
	pass
