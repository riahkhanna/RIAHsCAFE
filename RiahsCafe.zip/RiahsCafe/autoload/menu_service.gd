extends Node
## MenuService
##
## Filters the full authored menu (all MenuItemResource .tres assets)
## down to what's actually orderable right now: unlocked at the
## player's level AND has enough ingredients in stock. Customers only
## ever see this filtered view, never the raw catalog.

## Populate this in the editor (Inspector) by dragging in every
## MenuItemResource .tres, or load programmatically at boot via
## _load_menu_from_directory(). Left as an exported array so designers
## can manage it without touching code.
@export var full_catalog: Array[MenuItemResource] = []


func get_available_items() -> Array[MenuItemResource]:
	var available: Array[MenuItemResource] = []
	for item in full_catalog:
		if item.unlock_level > GameManager.player_level:
			continue
		if item.recipe and not InventoryManager.has_enough(item.recipe.ingredients):
			continue
		available.append(item)
	return available


func get_item_by_id(id: String) -> MenuItemResource:
	for item in full_catalog:
		if item.id == id:
			return item
	return null
