extends Control
## MainMenu
##
## First screen shown. Emits start_pressed and lets Main.gd decide what
## happens next - the menu itself has zero knowledge of scene paths,
## keeping it reusable for e.g. a "New Game" confirmation dialog later.

signal start_pressed

@onready var _continue_button: Button = %ContinueButton


func _ready() -> void:
	%NewGameButton.pressed.connect(_on_new_game_pressed)
	_continue_button.pressed.connect(_on_continue_pressed)
	_continue_button.disabled = not SaveManager.has_save()
	%QuitButton.pressed.connect(func(): get_tree().quit())


func _on_new_game_pressed() -> void:
	start_pressed.emit()


func _on_continue_pressed() -> void:
	SaveManager.load_game()
	start_pressed.emit()
