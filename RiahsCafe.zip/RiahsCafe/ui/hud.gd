extends CanvasLayer
## HUD
##
## Read-only presentation layer. Never mutates game state - only listens
## to EventBus and reflects it. This is what "UI never touches gameplay
## logic directly" looks like in practice: swap this entire scene for a
## redesign and nothing else in the codebase needs to change.

@onready var money_label: Label = %MoneyLabel
@onready var day_label: Label = %DayLabel
@onready var reputation_bar: ProgressBar = %ReputationBar
@onready var star_label: Label = %StarLabel
@onready var queue_label: Label = %QueueLabel
@onready var toast_container: VBoxContainer = %ToastContainer


func _ready() -> void:
	EventBus.money_changed.connect(_on_money_changed)
	EventBus.reputation_changed.connect(_on_reputation_changed)
	EventBus.star_rating_changed.connect(_on_star_rating_changed)
	EventBus.day_started.connect(_on_day_started)
	EventBus.queue_advanced.connect(_refresh_queue_label)
	EventBus.queue_joined.connect(_refresh_queue_label)
	EventBus.level_up.connect(_on_level_up)
	EventBus.customer_left.connect(_on_customer_left)

	money_label.text = "$%d" % EconomyManager.money
	day_label.text = "Day %d" % GameManager.current_day
	reputation_bar.value = GameManager.reputation
	star_label.text = "%.1f ★" % GameManager.star_rating


func _on_money_changed(new_amount: int, delta: int) -> void:
	money_label.text = "$%d" % new_amount
	_spawn_toast(("+$%d" if delta >= 0 else "-$%d") % absi(delta), delta >= 0)


func _on_reputation_changed(new_value: float, _delta: float) -> void:
	reputation_bar.value = new_value


func _on_star_rating_changed(new_rating: float) -> void:
	star_label.text = "%.1f ★" % new_rating


func _on_day_started(day_number: int) -> void:
	day_label.text = "Day %d" % day_number


func _on_level_up(new_level: int) -> void:
	_spawn_toast("Level Up! Now Level %d" % new_level, true)


func _on_customer_left(_customer: Node, reason: String) -> void:
	if reason == "impatient":
		_spawn_toast("A customer left unhappy...", false)


func _refresh_queue_label(_a = null, _b = null) -> void:
	queue_label.text = "Waiting: %d" % QueueManager.get_queue_length()


func _spawn_toast(text: String, positive: bool) -> void:
	if toast_container == null:
		return
	var label := Label.new()
	label.text = text
	label.modulate = Color(0.4, 0.85, 0.5) if positive else Color(0.85, 0.4, 0.4)
	toast_container.add_child(label)

	var tween := create_tween()
	tween.tween_property(label, "modulate:a", 0.0, 1.2).set_delay(0.8)
	tween.tween_callback(label.queue_free)
